<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <style>
        .error {
            border: 1px solid red;
        }

        body {
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column; /* Added for better alignment */
            height: 100vh;
            margin: 0;
            background: linear-gradient(to bottom right, #ffd1dc, #ffb6c1);
        }


        form {
            width: 180px;
            background-color: #fff; /* White */
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        input[type="submit"] {
            background-color: #3498db;
            color: #fff;
            border: 1px solid #2980b9;
            padding: 8px 15px;
            cursor: pointer;
        }

        input[type="reset"] {
            background-color: #f1c40f;
            color: #000;
            border: 1px solid #d4ac0d;
            padding: 8px 15px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" id="registrationForm" onsubmit="return validateForm()">
        <label for="fullname">Full Name:</label><br>
        <input type="text" name="fullname" id="fullname" required><br>

        <label for="username">Username:</label><br>
        <input type="text" name="username" id="username" required><br>

        <label>Gender:</label><br>
        <input type="radio" name="gender" value="male" checked> Male
        <input type="radio" name="gender" value="female"> Female<br>

        <label for="email">Email:</label><br>
        <input type="email" name="email" id="email" required><br>

        <label for="country">Country:</label><br>
        <input type="text" name="country" id="country" required><br>

        <label for="phonenumber">Phone Number:</label><br>
        <input type="tel" name="phonenumber" id="phonenumber" pattern="[0-9]{10,}" title="Please enter a valid 10-digit phone number" required><br>

        <label for="password">Password:</label><br>
        <input type="password" name="password" id="password" pattern=".{6,}" title="Password must be at least 6 characters" required><br>

        <label for="confirm_password">Confirm Password:</label><br>
        <input type="password" name="confirm_password" id="confirm_password" pattern=".{6,}" title="Password must be at least 6 characters" required><br><br>

        <input type="submit" value="Register">
        <input type="reset" value="Reset">
    </form>

    <?php
    // Database connection details
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "reg";

    // Create a database connection
    $conn = new mysqli($host, $username, $password, $database);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Function to sanitize user inputs
    function sanitize_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    // Process form submission
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $fullname = sanitize_input($_POST["fullname"]);
        $username = sanitize_input($_POST["username"]);
        $gender = sanitize_input($_POST["gender"]);
        $email = sanitize_input($_POST["email"]);
        $country = sanitize_input($_POST["country"]);
        $phonenumber = sanitize_input($_POST["phonenumber"]);
        $password = sanitize_input($_POST["password"]);
        $confirm_password = sanitize_input($_POST["confirm_password"]);

        // Validate password match
        if ($password !== $confirm_password) {
            echo "Password and Confirm Password do not match";
        } else {
            // Hash the password before storing in the database
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Insert user data into the database
            $sql = "INSERT INTO test (fullname, username, gender, email, country, phonenumber, password) VALUES ('$fullname', '$username', '$gender', '$email', '$country', '$phonenumber', 'password')";

            if ($conn->query($sql) === TRUE) {
                echo "Registration successful!";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }

        // Close the database connection
        $conn->close();
    }
    ?>

    <script>
        function validateForm() {
            var elements = document.getElementById("registrationForm").elements;
            var valid = true;

            for (var i = 0; i < elements.length; i++) {
                if (elements[i].type !== "submit" && elements[i].type !== "radio") {
                    if (elements[i].value.trim() === "") {
                        elements[i].classList.add("error");
                        valid = false;
                    } else {
                        elements[i].classList.remove("error");
                    }
                }
            }

            return valid;
        }
    </script>
</body>
</html>
